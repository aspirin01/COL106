public class BalancedBST extends BST {

    public void insert(int key){
        // TO be completed by students
    }

    public boolean delete(int key){
        // TO be completed by students
	return false;
    }

}
