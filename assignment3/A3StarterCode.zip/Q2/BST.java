import java.util.*;
public class BST {

    public BSTNode root;

    public BST() {
        root = null;
    }

    public void insert(int num) {
        // TO be completed by students
    }

    public boolean delete(int num) {
        // TO be completed by students
		return false;
    }

    public boolean search(int num) {
        // TO be completed by students
        return false;
    }

    public ArrayList<Integer> inorder() {
        // TO be completed by students
		ArrayList<Integer> al = new ArrayList<>();
		return al;
    }
    public ArrayList<Integer> preorder() {
        // TO be completed by students
		ArrayList<Integer> al = new ArrayList<>();
		return al;
    }
    public ArrayList<Integer> postorder() {
        // TO be completed by students
		ArrayList<Integer> al = new ArrayList<>();
		return al;
    }
}