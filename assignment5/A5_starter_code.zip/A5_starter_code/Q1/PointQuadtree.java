public class PointQuadtree {

    enum Quad {
        NW,
        NE,
        SW,
        SE
    }

    public PointQuadtreeNode root;

    public PointQuadtree() {
        this.root = null;
    }

    public boolean insert(CellTower a) {
        // TO be completed by students
        return true;
    }

    public boolean cellTowerAt(CellTower a) {
        // TO be completed by students
        return true;
    }

    public CellTower chooseCellTower(int x, int y, int r) {
        // TO be completed by students
        return null;
    }
    

}
