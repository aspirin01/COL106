import java.util.ArrayList;

public class Tree {

    public TreeNode root;

    public Tree() {
        root = null;
    }

    public void insert(String s) {
        // TO be completed by students
    }

    public boolean delete(String s) {
        // TO be completed by students
        return false;
    }

    public boolean search(String s) {
        // TO be completed by students
        return false;
    }
    
    public int increment(String s) {
        // TO be completed by students
        return 0;
    }

    public int decrement(String s) {
        // TO be completed by students
        return 0;
    }

    public int getHeight() {
        // TO be completed by students
        return 0;
    }

    public int getVal(String s) {
        // TO be completed by students
        return 0;
    }
}
